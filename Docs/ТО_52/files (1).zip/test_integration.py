"""
=============================================================
 PetFriends — Integration Tests: Web + API
 test_integration.py
=============================================================

Задание 1 — API → UI:          создать питомца через API, проверить в браузере
Задание 2 — UI → API:          добавить питомца через браузер, проверить через API
Задание 3 — API update → UI:   изменить возраст через API, проверить в UI после F5
Задание 4 — Параметризованный: 10 питомцев, время ответа ≤ 3с, нет 5xx

Запуск всех тестов:
    pytest test_integration.py -v -s

Запуск с HTML-отчётом:
    pytest test_integration.py -v -s --html=report.html --self-contained-html

Запуск отдельного задания:
    pytest test_integration.py::TestTask1_ApiToUI -v -s
=============================================================
"""

import time
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

from conftest import (
    WEB_URL,
    Sel,
    wait_sync,
    find_pet_rows,
    find_add_pet_btn,
    get_add_pet_form,
    try_find_element,
    _save_debug,
)


# ══════════════════════════════════════════════════════════════
#  ЗАДАНИЕ 1  |  API → UI
#  ─────────────────────────────────────────────────────────────
#  Шаг 1: создаём питомца через POST /api/create_pet_simple
#  Шаг 2: открываем /my_pets в браузере
#  Шаг 3: убеждаемся, что питомец есть в таблице
#  Шаг 4: проверяем совпадение имени, типа и возраста
# ══════════════════════════════════════════════════════════════
class TestTask1_ApiToUI:
    """API → UI: питомец, созданный через API, виден в браузере."""

    PET_NAME        = "IntegrationDog"
    PET_ANIMAL_TYPE = "Labrador"
    PET_AGE         = 3

    @pytest.fixture(autouse=True)
    def _setup_teardown(self, api):
        """Создаём питомца перед тестом, удаляем после."""
        resp = api.create_pet_simple(
            name=self.PET_NAME,
            animal_type=self.PET_ANIMAL_TYPE,
            age=self.PET_AGE,
        )
        assert resp.status_code == 200, (
            f"Не удалось создать питомца через API: "
            f"HTTP {resp.status_code}\n{resp.text}"
        )
        self._pet    = resp.json()
        self._pet_id = self._pet["id"]
        print(f"\n🐾 [setup] Создан питомец id={self._pet_id}, name={self.PET_NAME}")

        yield

        api.delete_pet(self._pet_id)
        print(f"\n🗑  [teardown] Удалён питомец id={self._pet_id}")

    # ──────────────────────────────────────────────────────────
    def test_pet_visible_in_my_pets_page(self, driver):
        """Питомец, созданный через API, отображается на странице 'Мои питомцы'."""
        wait_sync(2)                          # даём серверу сохранить запись
        driver.get(f"{WEB_URL}/my_pets")
        print(f"\n🌐 URL: {driver.current_url}")

        rows = find_pet_rows(driver, page="my_pets")
        assert rows, (
            "Таблица питомцев пуста или не найдена на /my_pets.\n"
            "Проверьте скриншот в debug_screenshots/"
        )

        pet_names = _extract_col(rows, col_index=1)
        print(f"📋 Имена питомцев в UI: {pet_names}")

        assert self.PET_NAME in pet_names, (
            f"Питомец '{self.PET_NAME}' не найден в UI.\n"
            f"Все имена в таблице: {pet_names}"
        )
        print(f"✅ Питомец '{self.PET_NAME}' найден в таблице UI")

    # ──────────────────────────────────────────────────────────
    def test_pet_fields_correct_in_ui(self, driver):
        """Все поля питомца в UI совпадают с данными, отправленными в API."""
        wait_sync(2)
        driver.get(f"{WEB_URL}/my_pets")

        rows = find_pet_rows(driver, page="my_pets")
        assert rows, "Таблица питомцев пуста или не найдена."

        # Ищем строку нашего питомца
        target_cells = _find_row_by_name(rows, self.PET_NAME)
        assert target_cells is not None, (
            f"Строка с именем '{self.PET_NAME}' не найдена.\n"
            f"Все имена: {_extract_col(rows, 1)}"
        )

        # Таблица: [фото | имя | тип | возраст | кнопка удаления]
        ui_name   = target_cells[1].text.strip()
        ui_type   = target_cells[2].text.strip()
        ui_age    = target_cells[3].text.strip()

        print(f"\n📊 UI данные: name='{ui_name}', type='{ui_type}', age='{ui_age}'")

        assert ui_name == self.PET_NAME, (
            f"Имя: ожидалось '{self.PET_NAME}', получено '{ui_name}'"
        )
        assert ui_type == self.PET_ANIMAL_TYPE, (
            f"Тип: ожидалось '{self.PET_ANIMAL_TYPE}', получено '{ui_type}'"
        )
        assert ui_age == str(self.PET_AGE), (
            f"Возраст: ожидалось '{self.PET_AGE}', получено '{ui_age}'"
        )
        print("✅ Все поля совпадают с данными API")


# ══════════════════════════════════════════════════════════════
#  ЗАДАНИЕ 2  |  UI → API
#  ─────────────────────────────────────────────────────────────
#  Шаг 1: заполняем форму добавления питомца в браузере
#  Шаг 2: запрашиваем GET /api/pets?filter=my_pets
#  Шаг 3: ищем питомца в JSON-ответе по имени
#  Шаг 4: проверяем id, name, age
# ══════════════════════════════════════════════════════════════
class TestTask2_UIToAPI:
    """UI → API: питомец, добавленный в браузере, присутствует в JSON API."""

    PET_NAME        = "SeleniumCat"
    PET_ANIMAL_TYPE = "British Shorthair"
    PET_AGE         = "2"

    @pytest.fixture(autouse=True)
    def _teardown(self, api):
        self._created_pet_id = None
        yield
        if self._created_pet_id:
            api.delete_pet(self._created_pet_id)
            print(f"\n🗑  [teardown] Удалён питомец id={self._created_pet_id}")

    # ──────────────────────────────────────────────────────────
    def test_pet_added_via_ui_exists_in_api(self, driver, api):
        """Питомец, добавленный через UI, присутствует в JSON-ответе API."""
        wait = WebDriverWait(driver, 15)

        # ── Шаг 1: переходим на главную/all_pets ─────────────
        driver.get(f"{WEB_URL}/my_pets")
        print(f"\n🌐 URL: {driver.current_url}")

        # ── Шаг 2: ищем кнопку «Добавить питомца» ────────────
        add_btn = find_add_pet_btn(driver)
        assert add_btn is not None, (
            "Кнопка 'Добавить питомца' не найдена.\n"
            "Проверьте скриншот в debug_screenshots/ — возможно нужно "
            "исправить селектор Sel.ADD_PET_BTN в conftest.py"
        )
        add_btn.click()
        print(f"🖱  Нажата кнопка добавления. URL: {driver.current_url}")

        # ── Шаг 3: заполняем форму ────────────────────────────
        try:
            form = get_add_pet_form(driver, wait)
        except TimeoutException:
            _save_debug(driver, "add_pet_form_not_found")
            pytest.fail(
                "Форма добавления питомца не загрузилась.\n"
                "Проверьте скриншот в debug_screenshots/"
            )

        form["name"].clear()
        form["name"].send_keys(self.PET_NAME)
        form["animal_type"].clear()
        form["animal_type"].send_keys(self.PET_ANIMAL_TYPE)
        form["age"].clear()
        form["age"].send_keys(self.PET_AGE)
        form["submit"].click()
        print(f"📝 Форма отправлена: name={self.PET_NAME}, age={self.PET_AGE}")

        # ── Шаг 4: ждём подтверждения (редирект или новая запись) ─
        wait_sync(3)

        # ── Шаг 5: проверяем через API ────────────────────────
        resp = api.get_my_pets()
        assert resp.status_code == 200, (
            f"API вернул неожиданный статус: {resp.status_code}"
        )

        pets = resp.json().get("pets", [])
        print(f"📡 API вернул {len(pets)} питомцев")

        matched = [p for p in pets if p.get("name") == self.PET_NAME]
        assert matched, (
            f"Питомец '{self.PET_NAME}' не найден в ответе API.\n"
            f"Все имена: {[p['name'] for p in pets]}"
        )

        pet = matched[0]
        self._created_pet_id = pet.get("id")

        # ── Шаг 6: проверяем корректность полей ──────────────
        assert pet.get("id"), "Поле 'id' пустое или отсутствует"
        assert len(pet["id"]) > 5, f"Подозрительно короткий id: '{pet['id']}'"

        assert pet.get("name") == self.PET_NAME, (
            f"name: ожидалось '{self.PET_NAME}', получено '{pet.get('name')}'"
        )
        assert str(pet.get("age")) == self.PET_AGE, (
            f"age: ожидалось '{self.PET_AGE}', получено '{pet.get('age')}'"
        )

        print(
            f"✅ Питомец найден в API:\n"
            f"   id='{pet['id']}'\n"
            f"   name='{pet['name']}'\n"
            f"   age={pet['age']}"
        )


# ══════════════════════════════════════════════════════════════
#  ЗАДАНИЕ 3  |  API update → UI refresh
#  ─────────────────────────────────────────────────────────────
#  Шаг 1: создаём питомца через API (возраст = 1)
#  Шаг 2: открываем /my_pets — видим возраст 1
#  Шаг 3: меняем возраст через PUT /api/pets/{id} (возраст = 5)
#  Шаг 4: driver.refresh()
#  Шаг 5: убеждаемся, что UI показывает возраст 5
# ══════════════════════════════════════════════════════════════
class TestTask3_ApiUpdateReflectedInUI:
    """API update → UI: изменение возраста через API видно в UI после перезагрузки."""

    PET_NAME        = "AgeChangePet"
    PET_ANIMAL_TYPE = "Beagle"
    INITIAL_AGE     = 1
    NEW_AGE         = 5

    @pytest.fixture(autouse=True)
    def _setup_teardown(self, api):
        resp = api.create_pet_simple(
            name=self.PET_NAME,
            animal_type=self.PET_ANIMAL_TYPE,
            age=self.INITIAL_AGE,
        )
        assert resp.status_code == 200, (
            f"Не удалось создать питомца: HTTP {resp.status_code}"
        )
        self._pet_id = resp.json()["id"]
        print(f"\n🐾 [setup] Создан питомец id={self._pet_id}, age={self.INITIAL_AGE}")

        yield

        api.delete_pet(self._pet_id)
        print(f"\n🗑  [teardown] Удалён питомец id={self._pet_id}")

    # ──────────────────────────────────────────────────────────
    def test_age_update_visible_after_ui_refresh(self, driver, api):
        """После PUT через API и driver.refresh() UI показывает новый возраст."""

        # ── Шаг 1: открываем UI, проверяем начальный возраст ─
        wait_sync(2)
        driver.get(f"{WEB_URL}/my_pets")
        print(f"\n🌐 URL: {driver.current_url}")

        rows = find_pet_rows(driver, page="my_pets")
        assert rows, "Таблица питомцев пуста — не удалось открыть /my_pets"

        old_age = _get_pet_age_from_ui(rows, self.PET_NAME)
        assert old_age is not None, (
            f"Питомец '{self.PET_NAME}' не найден в таблице на /my_pets.\n"
            f"Все имена: {_extract_col(rows, 1)}"
        )
        assert old_age == str(self.INITIAL_AGE), (
            f"Начальный возраст в UI: ожидалось '{self.INITIAL_AGE}', "
            f"получено '{old_age}'"
        )
        print(f"📊 Начальный возраст в UI: {old_age} ✓")

        # ── Шаг 2: меняем возраст через API ──────────────────
        update_resp = api.update_pet(
            pet_id=self._pet_id,
            name=self.PET_NAME,
            animal_type=self.PET_ANIMAL_TYPE,
            age=self.NEW_AGE,
        )
        assert update_resp.status_code == 200, (
            f"API PUT вернул: HTTP {update_resp.status_code}\n{update_resp.text}"
        )
        print(f"🔄 Возраст обновлён через API: {self.INITIAL_AGE} → {self.NEW_AGE}")

        # ── Шаг 3: обновляем страницу (F5) ───────────────────
        wait_sync(1)
        driver.refresh()
        print("🔃 Страница обновлена (refresh)")

        rows_after = find_pet_rows(driver, page="my_pets")
        assert rows_after, "После refresh таблица питомцев не найдена"

        # ── Шаг 4: проверяем новый возраст ───────────────────
        new_age = _get_pet_age_from_ui(rows_after, self.PET_NAME)
        assert new_age is not None, (
            f"Питомец '{self.PET_NAME}' не найден после refresh.\n"
            f"Все имена: {_extract_col(rows_after, 1)}"
        )
        assert new_age == str(self.NEW_AGE), (
            f"Возраст после обновления: ожидалось '{self.NEW_AGE}', "
            f"получено '{new_age}'"
        )
        print(f"✅ Новый возраст в UI: {new_age} (ожидалось {self.NEW_AGE})")


# ══════════════════════════════════════════════════════════════
#  ЗАДАНИЕ 4  |  Параметризованный нагрузочный тест
#  ─────────────────────────────────────────────────────────────
#  10 питомцев подряд. Для каждого проверяем:
#    • нет 5xx
#    • время ответа ≤ MAX_RESPONSE_TIME_SEC
#    • тело ответа содержит все обязательные поля
# ══════════════════════════════════════════════════════════════

PETS_BATCH = [
    ("LoadPet_01", "Husky",            1),
    ("LoadPet_02", "Persian Cat",      3),
    ("LoadPet_03", "Parrot",           5),
    ("LoadPet_04", "Goldfish",         2),
    ("LoadPet_05", "Turtle",          10),
    ("LoadPet_06", "Rabbit",           1),
    ("LoadPet_07", "Poodle",           4),
    ("LoadPet_08", "Siamese Cat",      6),
    ("LoadPet_09", "German Shepherd",  2),
    ("LoadPet_10", "Cockatiel",        7),
]

MAX_RESPONSE_TIME_SEC = 3.0


@pytest.mark.parametrize(
    "name, animal_type, age",
    PETS_BATCH,
    ids=[p[0] for p in PETS_BATCH],
)
class TestTask4_ParametrizedLoad:
    """
    Нагрузочный тест: 10 питомцев подряд.
    Каждая итерация: 3 независимых проверки.
    """

    @pytest.fixture(autouse=True)
    def _teardown(self, api):
        self._pet_id = None
        yield
        if self._pet_id:
            api.delete_pet(self._pet_id)

    # ── Проверка 1: нет 5xx ───────────────────────────────────
    def test_no_5xx_status(self, api, name, animal_type, age):
        """API не возвращает 5xx при создании питомца."""
        resp = api.create_pet_simple(name=name, animal_type=animal_type, age=age)

        # Сохраняем id для teardown (если создание прошло успешно)
        if resp.status_code == 200:
            self._pet_id = resp.json().get("id")

        assert resp.status_code < 500, (
            f"[{name}] Сервер вернул 5xx: HTTP {resp.status_code}\n"
            f"Тело ответа: {resp.text[:300]}"
        )
        assert resp.status_code == 200, (
            f"[{name}] Неожиданный статус: HTTP {resp.status_code}\n"
            f"Тело ответа: {resp.text[:300]}"
        )
        print(f"\n✅ [{name}] status={resp.status_code} | id={self._pet_id}")

    # ── Проверка 2: время ответа ──────────────────────────────
    def test_response_time_within_limit(self, api, name, animal_type, age):
        """Время ответа не превышает MAX_RESPONSE_TIME_SEC."""
        start   = time.perf_counter()
        resp    = api.create_pet_simple(name=name, animal_type=animal_type, age=age)
        elapsed = time.perf_counter() - start

        if resp.status_code == 200:
            self._pet_id = resp.json().get("id")

        assert elapsed <= MAX_RESPONSE_TIME_SEC, (
            f"[{name}] Время ответа {elapsed:.3f}s > лимита {MAX_RESPONSE_TIME_SEC}s"
        )
        print(
            f"\n⏱  [{name}] response_time={elapsed:.3f}s "
            f"(лимит {MAX_RESPONSE_TIME_SEC}s) — OK"
        )

    # ── Проверка 3: корректность тела ответа ─────────────────
    def test_response_body_correctness(self, api, name, animal_type, age):
        """Тело ответа содержит все обязательные поля с корректными значениями."""
        resp = api.create_pet_simple(name=name, animal_type=animal_type, age=age)
        assert resp.status_code == 200, (
            f"[{name}] HTTP {resp.status_code}: {resp.text[:200]}"
        )

        body = resp.json()
        self._pet_id = body.get("id")

        # ── Обязательные поля ─────────────────────────────────
        required_fields = ("id", "name", "animal_type", "age", "created_at", "user_id")
        for field in required_fields:
            assert field in body, (
                f"[{name}] Обязательное поле '{field}' отсутствует в ответе.\n"
                f"Поля ответа: {list(body.keys())}"
            )

        # ── Значения полей совпадают с отправленными ──────────
        assert body["id"], f"[{name}] Поле 'id' пустое"

        assert body["name"] == name, (
            f"[{name}] name: ожидалось '{name}', получено '{body['name']}'"
        )
        assert body["animal_type"] == animal_type, (
            f"[{name}] animal_type: ожидалось '{animal_type}', "
            f"получено '{body['animal_type']}'"
        )
        assert float(body["age"]) == float(age), (
            f"[{name}] age: ожидалось {age}, получено {body['age']}"
        )

        print(
            f"\n✅ [{name}] Все поля корректны:\n"
            f"   id='{body['id'][:8]}...'\n"
            f"   name='{body['name']}'\n"
            f"   animal_type='{body['animal_type']}'\n"
            f"   age={body['age']}"
        )


# ══════════════════════════════════════════════════════════════
#  ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ══════════════════════════════════════════════════════════════

def _extract_col(rows: list, col_index: int) -> list:
    """Извлекает текст указанного столбца из всех строк таблицы."""
    result = []
    for row in rows:
        cells = row.find_elements(By.TAG_NAME, "td")
        if len(cells) > col_index:
            result.append(cells[col_index].text.strip())
    return result


def _find_row_by_name(rows: list, name: str):
    """Находит ячейки строки, где второй столбец (имя) совпадает с name."""
    for row in rows:
        cells = row.find_elements(By.TAG_NAME, "td")
        if len(cells) >= 4 and cells[1].text.strip() == name:
            return cells
    return None


def _get_pet_age_from_ui(rows: list, name: str):
    """Возвращает текст возраста питомца из таблицы или None."""
    cells = _find_row_by_name(rows, name)
    if cells and len(cells) >= 4:
        return cells[3].text.strip()
    return None
