"""
=============================================================
 PetFriends — Integration Test Suite
 conftest.py  |  Фикстуры, утилиты, селекторы
=============================================================
"""

import os
import time
import pytest
import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException


# ─────────────────────────────────────────────────────────────
#  НАСТРОЙКИ  (замените на реальные учётные данные)
# ─────────────────────────────────────────────────────────────
BASE_URL    = "https://petfriends.skillfactory.ru"
WEB_URL     = "https://petfriends.skillfactory.ru"
USER_EMAIL  = "your_email@mail.ru"   # ← замените
USER_PASS   = "your_password"        # ← замените
API_TIMEOUT = 10


# ─────────────────────────────────────────────────────────────
#  СЕЛЕКТОРЫ  (централизованное место — легко менять)
# ─────────────────────────────────────────────────────────────
class Sel:
    """Все CSS/XPath-селекторы сайта в одном месте."""

    # Страница входа
    LOGIN_EMAIL    = (By.ID,   "email")
    LOGIN_PASS     = (By.ID,   "pass")
    LOGIN_SUBMIT   = (By.CSS_SELECTOR, "button[type='submit']")

    # Навигация — ссылка «Мои питомцы»
    NAV_MY_PETS = [
        (By.CSS_SELECTOR, "a[href='/my_pets']"),
        (By.XPATH,        "//a[contains(text(),'Мои питомцы')]"),
        (By.XPATH,        "//a[normalize-space()='Мои питомцы']"),
    ]

    # Блок «Мои питомцы» на странице /my_pets
    MY_PETS_TABLE_ROW = [
        (By.CSS_SELECTOR, "#my_pets .table tbody tr"),
        (By.CSS_SELECTOR, "#my_pets table tbody tr"),
        (By.XPATH,        "//div[@id='my_pets']//table//tbody//tr"),
        (By.XPATH,        "//table[contains(@class,'table')]//tbody//tr"),
    ]

    # Таблица всех питомцев на /all_pets
    ALL_PETS_TABLE_ROW = [
        (By.CSS_SELECTOR, ".table tbody tr"),
        (By.XPATH,        "//table//tbody//tr"),
    ]

    # Кнопка/ссылка добавления питомца
    ADD_PET_BTN = [
        (By.CSS_SELECTOR, "a[href='/add_pet']"),
        (By.XPATH,        "//a[contains(text(),'Добавить питомца')]"),
        (By.XPATH,        "//button[contains(text(),'Добавить питомца')]"),
        (By.XPATH,        "//a[contains(@href,'add_pet')]"),
        (By.XPATH,        "//a[contains(text(),'добавить')]"),
    ]

    # Форма добавления питомца (поля)
    FORM_NAME        = (By.ID, "name")
    FORM_ANIMAL_TYPE = (By.ID, "animal_type")
    FORM_AGE         = (By.ID, "age")
    FORM_SUBMIT      = (By.CSS_SELECTOR, "button[type='submit']")

    # После авторизации — признаки успеха
    POST_LOGIN_INDICATORS = [
        "/all_pets",
        "/my_pets",
        "/?",
        "/",
    ]


# ─────────────────────────────────────────────────────────────
#  УТИЛИТЫ  (надёжное нахождение элементов)
# ─────────────────────────────────────────────────────────────
def _save_debug(driver, name: str = "debug"):
    """Сохраняет скриншот и исходник страницы для диагностики."""
    out_dir = os.path.join(os.path.dirname(__file__), "debug_screenshots")
    os.makedirs(out_dir, exist_ok=True)
    ts = time.strftime("%H%M%S")
    png = os.path.join(out_dir, f"{ts}_{name}.png")
    html = os.path.join(out_dir, f"{ts}_{name}.html")
    try:
        driver.save_screenshot(png)
        with open(html, "w", encoding="utf-8") as f:
            f.write(driver.page_source)
        print(f"\n🖼  Debug saved: {png}")
        print(f"📄  HTML saved:  {html}")
    except Exception as e:
        print(f"\n⚠  Не удалось сохранить debug-файлы: {e}")


def try_find_element(driver, selectors: list, timeout: int = 10):
    """
    Пробует найти элемент по списку селекторов по очереди.
    Возвращает первый найденный WebElement или None.
    """
    for by, value in selectors:
        try:
            el = WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located((by, value))
            )
            return el
        except TimeoutException:
            continue
    return None


def try_find_elements(driver, selectors: list, timeout: int = 10):
    """
    Пробует найти список элементов по очереди из переданных селекторов.
    Возвращает первый непустой список или [].
    """
    for by, value in selectors:
        try:
            WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located((by, value))
            )
            els = driver.find_elements(by, value)
            if els:
                return els
        except TimeoutException:
            continue
    return []


def find_pet_rows(driver, page: str = "my_pets") -> list:
    """
    Ищет строки таблицы питомцев на странице.
    page='my_pets'  → используем MY_PETS_TABLE_ROW
    page='all_pets' → используем ALL_PETS_TABLE_ROW
    """
    selectors = (Sel.MY_PETS_TABLE_ROW
                 if page == "my_pets"
                 else Sel.ALL_PETS_TABLE_ROW)
    rows = try_find_elements(driver, selectors, timeout=15)
    if not rows:
        _save_debug(driver, f"no_rows_{page}")
    return rows


def find_add_pet_btn(driver):
    """Ищет кнопку/ссылку «Добавить питомца»."""
    btn = try_find_element(driver, Sel.ADD_PET_BTN, timeout=10)
    if not btn:
        _save_debug(driver, "no_add_pet_btn")
    return btn


def get_add_pet_form(driver, wait: WebDriverWait):
    """Ждёт появления формы добавления питомца и возвращает поля."""
    wait.until(EC.presence_of_element_located(Sel.FORM_NAME))
    return {
        "name":        driver.find_element(*Sel.FORM_NAME),
        "animal_type": driver.find_element(*Sel.FORM_ANIMAL_TYPE),
        "age":         driver.find_element(*Sel.FORM_AGE),
        "submit":      driver.find_element(*Sel.FORM_SUBMIT),
    }


def wait_sync(seconds: float = 2.0):
    """Пауза для синхронизации UI с изменениями через API."""
    time.sleep(seconds)


# ─────────────────────────────────────────────────────────────
#  ФИКСТУРА: API-ключ  (один раз на всю сессию)
# ─────────────────────────────────────────────────────────────
@pytest.fixture(scope="session")
def auth_key() -> str:
    response = requests.get(
        f"{BASE_URL}/api/key",
        headers={"email": USER_EMAIL, "password": USER_PASS},
        timeout=API_TIMEOUT,
    )
    assert response.status_code == 200, (
        f"Не удалось получить API-ключ: HTTP {response.status_code}\n{response.text}"
    )
    key = response.json().get("key")
    assert key, "Сервер вернул пустой API-ключ"
    return key


# ─────────────────────────────────────────────────────────────
#  ФИКСТУРА: API-клиент
# ─────────────────────────────────────────────────────────────
@pytest.fixture(scope="session")
def api(auth_key):
    class PetFriendsAPI:
        def __init__(self, key: str):
            self.key = key
            self._h  = {"auth_key": key}

        def get_my_pets(self):
            return requests.get(
                f"{BASE_URL}/api/pets",
                headers=self._h,
                params={"filter": "my_pets"},
                timeout=API_TIMEOUT,
            )

        def create_pet_simple(self, name, animal_type, age):
            return requests.post(
                f"{BASE_URL}/api/create_pet_simple",
                headers=self._h,
                data={"name": name, "animal_type": animal_type, "age": age},
                timeout=API_TIMEOUT,
            )

        def update_pet(self, pet_id, name=None, animal_type=None, age=None):
            payload = {}
            if name        is not None: payload["name"]        = name
            if animal_type is not None: payload["animal_type"] = animal_type
            if age         is not None: payload["age"]         = age
            return requests.put(
                f"{BASE_URL}/api/pets/{pet_id}",
                headers=self._h,
                data=payload,
                timeout=API_TIMEOUT,
            )

        def delete_pet(self, pet_id):
            return requests.delete(
                f"{BASE_URL}/api/pets/{pet_id}",
                headers=self._h,
                timeout=API_TIMEOUT,
            )

    return PetFriendsAPI(auth_key)


# ─────────────────────────────────────────────────────────────
#  ФИКСТУРА: Selenium WebDriver
# ─────────────────────────────────────────────────────────────
@pytest.fixture(scope="function")
def driver():
    """
    Запускает Chrome headless, авторизуется через UI,
    диагностирует проблему если логин не удался.
    """
    options = Options()
    options.add_argument("--headless=new")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-gpu")
    options.add_argument("--ignore-certificate-errors")

    drv = webdriver.Chrome(options=options)
    drv.implicitly_wait(0)           # отключаем implicit — используем explicit
    wait = WebDriverWait(drv, 15)

    # ── Авторизация ──────────────────────────────────────────
    drv.get(f"{WEB_URL}/login")

    try:
        wait.until(EC.presence_of_element_located(Sel.LOGIN_EMAIL))
    except TimeoutException:
        _save_debug(drv, "login_page_not_loaded")
        drv.quit()
        pytest.fail(
            "Страница /login не загрузилась — поле #email не найдено за 15 сек.\n"
            "Проверьте: WEB_URL, доступность сайта, скриншот в debug_screenshots/"
        )

    drv.find_element(*Sel.LOGIN_EMAIL).send_keys(USER_EMAIL)
    drv.find_element(*Sel.LOGIN_PASS).send_keys(USER_PASS)
    drv.find_element(*Sel.LOGIN_SUBMIT).click()

    # ── Ждём редиректа после логина (несколько вариантов URL) ─
    login_ok = False
    for _ in range(20):           # до 4 секунд
        url = drv.current_url
        if any(ind in url for ind in ["/all_pets", "/my_pets", "petfriends"]
               if url != f"{WEB_URL}/login"):
            login_ok = True
            break
        # Дополнительно — ищем признак авторизованной страницы
        try:
            if drv.find_element(By.CSS_SELECTOR, ".navbar-nav"):
                login_ok = True
                break
        except NoSuchElementException:
            pass
        time.sleep(0.2)

    if not login_ok:
        # Мягкая проверка — возможно редирект прошёл нестандартно
        if drv.current_url != f"{WEB_URL}/login":
            login_ok = True   # ушли со страницы логина — считаем успехом

    if not login_ok:
        _save_debug(drv, "login_failed")
        drv.quit()
        pytest.fail(
            f"Авторизация не прошла. URL после submit: {drv.current_url}\n"
            f"Проверьте USER_EMAIL / USER_PASS в conftest.py\n"
            f"Скриншот сохранён в debug_screenshots/"
        )

    print(f"\n🔑 Авторизован. Текущий URL: {drv.current_url}")
    yield drv
    drv.quit()


# ─────────────────────────────────────────────────────────────
#  HOOK: автосохранение скриншота при падении теста
# ─────────────────────────────────────────────────────────────
@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    if rep.when == "call" and rep.failed:
        drv = item.funcargs.get("driver")
        if drv:
            test_name = item.name.replace("[", "_").replace("]", "")
            _save_debug(drv, f"FAIL_{test_name}")
